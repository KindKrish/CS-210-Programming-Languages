// CS 210 Project Three - Corner Grocer Item Tracker
// Reads purchased items, counts frequencies, and provides a simple menu.
#include <cctype>
#include <fstream>
#include <iostream>
#include <limits>
#include <map>
#include <string>
using namespace std;

class GroceryTracker {
private:
    map<string, int> itemCounts;  // Stores each item and its purchase count.

    // Make searches case-insensitive without changing the displayed names.
    static string normalize(string word) {
        for (char& letter : word) {
            letter = static_cast<char>(tolower(static_cast<unsigned char>(letter)));
        }
        return word;
    }

public:
    // Read the store's purchase records into the map.
    bool loadItems(const string& fileName) {
        ifstream inputFile(fileName);
        if (!inputFile.is_open()) {
            cerr << "Error: Could not open " << fileName << endl;
            return false;
        }
        string item;
        while (inputFile >> item) {
            ++itemCounts[normalize(item)];
        }
        if (inputFile.bad()) {
            cerr << "Error: Could not finish reading the input file." << endl;
            return false;
        }
        return true;
    }

    // Save a backup as soon as the input has been read.
    bool saveBackup(const string& fileName) const {
        ofstream outputFile(fileName);
        if (!outputFile.is_open()) {
            cerr << "Error: Could not create " << fileName << endl;
            return false;
        }
        for (const auto& entry : itemCounts) {
            outputFile << entry.first << " " << entry.second << '\n';
        }
        outputFile.close();
        return outputFile.good();
    }

    int getFrequency(const string& item) const {
        auto found = itemCounts.find(normalize(item));
        return found == itemCounts.end() ? 0 : found->second;
    }

    void displayFrequencies() const {
        cout << "\nItem frequencies:\n";
        for (const auto& entry : itemCounts) {
            cout << entry.first << " " << entry.second << '\n';
        }
    }

    void displayHistogram() const {
        cout << "\nPurchase histogram:\n";
        for (const auto& entry : itemCounts) {
            cout << entry.first << " " << string(entry.second, '*') << '\n';
        }
    }
};

int main() {
    GroceryTracker tracker;
    if (!tracker.loadItems("CS210_Project_Three_Input_File.txt")) {
        return 1;
    }
    if (!tracker.saveBackup("frequency.dat")) {
        cerr << "The backup could not be saved.\n";
        return 1;
    }

    int choice = 0;
    while (choice != 4) {
        cout << "\n========== CORNER GROCER ==========\n"
             << "1. Search for an item\n"
             << "2. Display item frequencies\n"
             << "3. Display frequency histogram\n"
             << "4. Exit\n"
             << "===================================\n"
             << "Enter your choice: ";
        if (!(cin >> choice)) {
            if (cin.eof()) break;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Please enter a number from 1 to 4.\n";
            continue;
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        if (choice == 1) {
            string item;
            cout << "Enter an item name: ";
            getline(cin, item);
            cout << "Number purchased: " << tracker.getFrequency(item) << '\n';
        } else if (choice == 2) {
            tracker.displayFrequencies();
        } else if (choice == 3) {
            tracker.displayHistogram();
        } else if (choice == 4) {
            cout << "Thank you for using Corner Grocer!\n";
        } else {
            cout << "Please enter a number from 1 to 4.\n";
        }
    }
    return 0;
}
