Corner Grocer - CS 210 Project Three

Open CornerGrocer.sln in Visual Studio 2022, build, and run.
The program expects CS210_Project_Three_Input_File.txt in its working directory.
In Visual Studio, set project Properties > Debugging > Working Directory to $(ProjectDir) if needed.
The program automatically writes frequency.dat on startup.

Alternative: In this folder, run:
g++ -std=c++11 main.cpp -o corner_grocer
./corner_grocer

Sample output in sample_output.txt was captured from the compiled C++ program.
